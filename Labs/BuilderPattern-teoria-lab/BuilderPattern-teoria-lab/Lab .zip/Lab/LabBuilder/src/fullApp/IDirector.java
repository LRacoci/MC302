package fullApp;

public interface IDirector {
    public void construct();
}
